Sourcemod's default supported languanges.

/*"Languages"
{
	"en"		"English"
	"ar"		"Arabic"		// (17) Arabic
	"pt"		"Brazilian"		// (24) Brazilian Portuguese
	"bg"		"Bulgarian"		// (38) Bulgarian
	"cze"		"Czech"		// (34) Czech
	"da"		"Danish"		// (28) Danish
	"nl"		"Dutch"		// (7) Dutch
	"fi"		"Finnish"		// (31) Finnish
	"fr"		"French"		// (11) French
	"de"		"German"		// (4) German
	"el"		"Greek"		// (41) Greek
	"he"		"Hebrew"		// (35) Hebrew
	"hu"		"Hungarian"		// (18) Hungarian
	"it"		"Italian"		// (27) Italian
	"jp"		"Japanese"		// (37) Japanese
	"ko"		"KoreanA"		// (15) Korean
	"ko"		"Korean"		// (15) Korean
	"lv"		"Latvian"		// (32) Latvian
	"lt"		"Lithuanian"		// (25) Lithuanian
	"no"		"Norwegian"		// (22) Norwegian
	"pl"		"Polish"		// (20) Polish
	"pt_p"		"Portuguese"		// (40) Portuguese
	"ro"		"Romanian"		// (16) Romanian
	"ru"		"Russian"		// (12) Russian
	"chi"		"SChinese"		// (13) Chinese (Simplified)
	"sk"		"Slovak"		// (21) Slovak
	"es"		"Spanish"		// (2) Spanish
	"sv"		"Swedish"		// (19) Swedish
	"zho"		"TChinese"		// (14) Chinese (Traditional)
	"th"		"Thai"		// (39) Thai
	"tr"		"Turkish"		// (23) Turkish
	"ua"		"Ukrainian"		// (42) Ukrainian
}*/

To add your own translations you need to input you language tag as ab example we use russian("ru")

For each key example key:"Lux's Model Changer" you add your language tag with the translation on the same line, 
you are limited to 191 characters for the translation of each key translation(i'm not sure about multibyte characters).

"Lux's Model Changer"
{
	"en"		"Lux's Model Changer"
	"ru"		"Смена персонажа (от Lux)"
	"zho"		"Lux的角色模型修改器"
}

And Repeat for each key.